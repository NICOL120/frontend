declare namespace JSX {
    interface Element {}
}
